invalid Apple Books export
